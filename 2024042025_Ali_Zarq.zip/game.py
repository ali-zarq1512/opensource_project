import random

def print_board(board):
    for row in board:
        print(" | ".join(row))
        print("-" * 9)

def check_winner(board, mark):
    for row in board:
        if all(s == mark for s in row):
            return True
    for col in range(3):
        if all(board[row][col] == mark for row in range(3)):
            return True
    if all(board[i][i] == mark for i in range(3)) or all(board[i][2 - i] == mark for i in range(3)):
        return True
    return False

def get_available_moves(board):
    return [(r, c) for r in range(3) for c in range(3) if board[r][c] == " "]

def player_move(board):
    while True:
        try:
            row, col = map(int, input("Enter row and column (0-2): ").split())
            if (row, col) in get_available_moves(board):
                board[row][col] = "X"
                break
            else:
                print("Invalid move. Try again.")
        except ValueError:
            print("Invalid input. Enter numbers between 0 and 2.")

def computer_move(board):
    move = random.choice(get_available_moves(board))
    board[move[0]][move[1]] = "O"

def main():
    board = [[" " for _ in range(3)] for _ in range(3)]
    print("Welcome to Tic-Tac-Toe! You are 'X', and the computer is 'O'.")
    
    for turn in range(9):
        print_board(board)
        if turn % 2 == 0:
            player_move(board)
            if check_winner(board, "X"):
                print_board(board)
                print("You win!")
                return
        else:
            computer_move(board)
            if check_winner(board, "O"):
                print_board(board)
                print("Computer wins!")
                return
    
    print_board(board)
    print("It's a draw!")

if __name__ == "__main__":
    main()
