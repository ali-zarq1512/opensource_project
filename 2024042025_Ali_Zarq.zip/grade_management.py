class Student:
    def __init__(self, student_id, name, english, c_language, python):
        self.student_id = student_id
        self.name = name
        self.english = english
        self.c_language = c_language
        self.python = python
        self.total = 0
        self.average = 0.0
        self.grade = ''
        self.rank = 0
        self.calculate_scores()

    def calculate_scores(self):
        self.total = self.english + self.c_language + self.python
        self.average = self.total / 3
        self.grade = self.calculate_grade()

    def calculate_grade(self):
        if self.average >= 90:
            return 'A'
        elif self.average >= 80:
            return 'B'
        elif self.average >= 70:
            return 'C'
        elif self.average >= 60:
            return 'D'
        else:
            return 'F'

class GradeManager:
    def __init__(self):
        self.students = []

    def insert_student(self):
        student_id = input("Enter Student ID: ")
        name = input("Enter Name: ")
        english = int(input("Enter English Score: "))
        c_language = int(input("Enter C-Language Score: "))
        python = int(input("Enter Python Score: "))
        
        student = Student(student_id, name, english, c_language, python)
        self.students.append(student)
        self.calculate_ranks()

    def delete_student(self):
        student_id = input("Enter Student ID to delete: ")
        self.students = [s for s in self.students if s.student_id != student_id]
        self.calculate_ranks()
        print("Student deleted successfully!")

    def search_student(self):
        search_term = input("Enter Student ID or Name to search: ")
        found_students = [s for s in self.students if s.student_id == search_term or s.name == search_term]
        
        if found_students:
            for s in found_students:
                self.display_student(s)
        else:
            print("Student not found!")

    def calculate_ranks(self):
        self.students.sort(key=lambda s: s.total, reverse=True)
        for i, student in enumerate(self.students):
            student.rank = i + 1

    def sort_by_total_score(self):
        self.students.sort(key=lambda s: s.total, reverse=True)

    def count_high_scorers(self):
        count = sum(1 for s in self.students if s.average >= 80)
        print(f"Number of students with average 80 or more: {count}")

    def display_student(self, student):
        print(f"{student.student_id} {student.name} | English: {student.english} | C-Lang: {student.c_language} | Python: {student.python} | Total: {student.total} | Avg: {student.average:.2f} | Grade: {student.grade} | Rank: {student.rank}")

    def display_all_students(self):
        if not self.students:
            print("No students available!")
            return
        for student in self.students:
            self.display_student(student)

def main():
    gm = GradeManager()
    while True:
        print("\n1. Insert Student\n2. Delete Student\n3. Search Student\n4. Sort by Total Score\n5. Count Students (80+)\n6. Display All\n7. Exit")
        choice = input("Enter your choice: ")
        
        if choice == '1':
            gm.insert_student()
        elif choice == '2':
            gm.delete_student()
        elif choice == '3':
            gm.search_student()
        elif choice == '4':
            gm.sort_by_total_score()
            print("Sorted by total score!")
        elif choice == '5':
            gm.count_high_scorers()
        elif choice == '6':
            gm.display_all_students()
        elif choice == '7':
            break
        else:
            print("Invalid choice! Try again.")

if __name__ == "__main__":
    main()
